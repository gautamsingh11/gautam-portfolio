import { ArrowUpRight, Code2, GitBranch, Link2, Mail, Sparkles } from 'lucide-react'

const links = [
  { label: 'GitHub', detail: 'gautamsingh11', icon: GitBranch, href: 'https://github.com/gautamsingh11', external: true },
  { label: 'LinkedIn', detail: 'gautam-kumar-57914b287', icon: Link2, href: 'https://www.linkedin.com/in/gautam-kumar-57914b287/', external: true },
  { label: 'Email', detail: 'gautamsingh4350@gmail.com', icon: Mail, href: 'mailto:gautamsingh4350@gmail.com', external: false },
]

const skillGroups = [
  { title: 'Frontend Development', skills: ['React.js', 'JavaScript (ES6+)', 'HTML5', 'CSS3', 'Tailwind CSS', 'Bootstrap', 'Responsive Web Design'] },
  { title: 'Backend Development', skills: ['Node.js', 'Express.js', 'RESTful API Design and Integration', 'MVC Architecture'] },
  { title: 'Databases', skills: ['MongoDB', 'SQL'] },
  { title: 'Authentication and Security', skills: ['JWT Authentication', 'Application Security Fundamentals', 'Network Security Fundamentals'] },
  { title: 'Programming Languages', skills: ['Java', 'Python', 'C++'] },
  { title: 'Tools and Deployment', skills: ['Git', 'GitHub', 'Docker', 'Visual Studio Code'] },
  { title: 'Core Computer Science', skills: ['Data Structures and Algorithms (DSA)', 'Object-Oriented Programming (OOP)', 'Operating Systems', 'Computer Networks', 'DBMS'] },
]

const projects = [
  {
    number: '01',
    title: 'News Web Application',
    description: 'A responsive news experience focused on clear content discovery and a smooth reading flow.',
    stack: 'React.js · JavaScript · API integration',
  },
  {
    number: '02',
    title: 'Blockchain Supply Chain Tracking',
    description: 'A web application for improving visibility and traceability across supply chain data.',
    stack: 'Web application · Blockchain · Data tracking',
  },
]

export default function Page() {
  return (
    <main className="calling-card-shell">
      <div className="ambient-glow ambient-glow-one" aria-hidden="true" />
      <div className="ambient-glow ambient-glow-two" aria-hidden="true" />

      <nav className="site-nav" aria-label="Main navigation">
        <a className="brand-mark" href="#top" aria-label="Gautam Kumar home">
          <span className="brand-mark-icon"><Code2 size={17} strokeWidth={2.5} /></span>
          <span>GK<span className="brand-dot">.</span></span>
        </a>
        <div className="nav-links">
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a className="nav-contact" href="#connect">Let&apos;s connect <ArrowUpRight size={15} /></a>
        </div>
      </nav>

      <section className="hero-section" id="top">
        <div className="hero-copy">
          <p className="eyebrow"><Sparkles size={15} /> Available for opportunities</p>
          <h1>Gautam<br /><span>Kumar</span></h1>
          <p className="hero-role">Full Stack Developer</p>
          <p className="hero-intro">MCA student and fresher with hands-on experience building thoughtful, practical web applications from front end to back end.</p>
          <div className="hero-actions">
            <a className="primary-action" href="#projects">Explore my work <ArrowUpRight size={16} /></a>
            <a className="text-action" href="#connect">Get in touch</a>
          </div>
        </div>
        <div className="hero-visual" aria-label="Developer profile mark">
          <div className="orbit orbit-outer" aria-hidden="true" />
          <div className="orbit orbit-inner" aria-hidden="true" />
          <div className="monogram">GK<span>.</span></div>
          <div className="visual-caption"><span className="status-dot" /> Building for the web</div>
        </div>
      </section>

      <section className="intro-section">
        <div className="section-label"><span>01</span><span className="section-line" /><span>Profile</span></div>
        <div className="about-grid">
          <h2>Curious by nature.<br /><em>Builder by choice.</em></h2>
          <p>I&apos;m an MCA student and fresher with hands-on experience creating web applications that are useful, clear, and built to grow. I enjoy turning ideas into reliable digital experiences and learning something new with every project.</p>
        </div>
      </section>

      <section className="skills-section" id="skills">
        <div className="section-label"><span>02</span><span className="section-line" /><span>Skills</span></div>
        <div className="skills-heading"><h2>Tools I use to<br /><em>bring ideas to life.</em></h2><p>Core technologies I&apos;ve worked with while building full stack web applications.</p></div>
        <div className="skills-groups" aria-label="Technical skills">{skillGroups.map((group) => (
          <article className="skill-group" key={group.title}>
            <h3>{group.title}</h3>
            <div className="skills-list">{group.skills.map((skill) => <span key={skill}>{skill}</span>)}</div>
          </article>
        ))}</div>
      </section>

      <section className="projects-section" id="projects">
        <div className="section-label"><span>03</span><span className="section-line" /><span>Selected projects</span></div>
        <div className="project-grid">{projects.map((project) => (
          <article className="project-card" key={project.title}>
            <div className="project-card-top"><span className="project-number">{project.number}</span><ArrowUpRight size={20} /></div>
            <div><h3>{project.title}</h3><p>{project.description}</p></div>
            <span className="project-stack">{project.stack}</span>
          </article>
        ))}</div>
      </section>

      <section className="connect-section" id="connect">
        <div className="section-label"><span>04</span><span className="section-line" /><span>How to reach me</span></div>
        <div className="connect-heading"><h2>Let&apos;s build<br /><span>something useful.</span></h2><p>Find me online or send a message directly.</p></div>
        <div className="contact-grid">{links.map(({ label, detail, icon: Icon, href, external }) => (
          <a className="contact-card" href={href} key={label} aria-label={`${label}: ${detail}`} {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>
            <span className="contact-icon"><Icon size={20} aria-hidden="true" /></span><span><strong>{label}</strong><small>{detail}</small></span><ArrowUpRight className="contact-arrow" size={17} aria-hidden="true" />
          </a>
        ))}</div>
      </section>

      <footer className="site-footer"><span>© {new Date().getFullYear()} Gautam Kumar</span><span>Full Stack Developer</span></footer>
    </main>
  )
}
